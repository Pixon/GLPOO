import java.awt.Color;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.SwingConstants;

public class fenetreMenu extends JFrame implements ActionListener
{
	Game linkedGameModel = null;
	Fight currentFight = null;
	BoutonImage Jouer = new BoutonImage("", "jouer.jpg","jouer2.jpg");
	BoutonImage Quitter = new BoutonImage("","quitter.jpg","quitter2.jpg");
	BoutonImage Options = new BoutonImage("","options.jpg","options2.jpg");
	BoutonImage Aide = new BoutonImage("","aide.jpg","aide2.jpg");	
	BoutonImage Menu = new BoutonImage("","menu.jpg","menu.jpg");
	BoutonImage Combat = new BoutonImage("","jouer.jpg","jouer.jpg");
	//r�cup�ration
	
	public fenetreMenu(Game game)
	{
		this.linkedGameModel = game;
	}
	
	
	
	public void Menu()
	{
		//D�finition des �l�ments
		BackgroundPanel fond = new BackgroundPanel("PokeFont4.gif");//Image de Fond
		
		//Param�tres de a fen�tre
		this.setTitle("POKEMILLION !");
		//Taille � modifier en fonction de l'image de fond !
		this.setSize(800, 475);
		this.setResizable(false);
		this.setLocationRelativeTo(null);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.setContentPane(fond);
		this.setVisible(true);
		//Ajout 
		fond.add(Jouer);
		fond.add(Options);
		fond.add(Aide);
		fond.add(Quitter);
		//Action Listener pour g�rer les actions sur les boutons
		Jouer.addActionListener(this);
		Quitter.addActionListener(this);
		Options.addActionListener(this);
		Aide.addActionListener(this);
	}	
	public void FichePoke(Fight fight)
	{
		this.currentFight = fight;
		Pokemon firstPokemon = fight.getFirstPokemon();
		Pokemon secondPokemon = fight.getSecondPokemon();
		//D�finition des �l�ments
		BackgroundPanel fondFiche = new BackgroundPanel("BackgroundFiche.jpg");//Image de Fond
		
		//Param�tres de a fen�tre
		this.setTitle("POKEMILLION !");
		//Taille � modifier en fonction de l'image de fond !
		this.setSize(1024, 768);
		this.setResizable(false);
		this.setLocationRelativeTo(null);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.setContentPane(fondFiche);
		this.setLayout(new GridLayout(14,2,5,2));
		Font police = new Font("Calibri",Font.BOLD, 35);
		JLabel vie1 = new JLabel(firstPokemon.getCurrentHealth() + " / " + firstPokemon.getCurrentStats().getHealth());
		vie1.setFont(police);
		vie1.setForeground(Color.WHITE);
		JLabel vie2 = new JLabel(secondPokemon.getCurrentHealth() + " / " + secondPokemon.getCurrentStats().getHealth());
		vie2.setFont(police);
		vie2.setForeground(Color.WHITE);
		JLabel nom1 = new JLabel(firstPokemon.getName() + "   lvl " + firstPokemon.getLevel());
		nom1.setFont(police);
		nom1.setForeground(Color.WHITE);
		JLabel nom2 = new JLabel(secondPokemon.getName() + "   lvl " + secondPokemon.getLevel());
		nom2.setFont(police);
		nom2.setForeground(Color.WHITE);
		JLabel imagepoke1 = new JLabel();
		ImageIcon image1 = new ImageIcon("001.gif"); //"pokemonImages/" + firstPokemon.getName() + ".gif"
		imagepoke1.setIcon(image1);
		JLabel imagepoke2 = new JLabel();
		ImageIcon image2 = new ImageIcon("001.gif");//"pokemonImages/" + secondPokemon.getName() + ".gif"
		imagepoke2.setIcon(image2);
		String firstPokemonType = firstPokemon.getPokemonRace().getFirstType();
		if (firstPokemonType != firstPokemon.getPokemonRace().getSecondType())
		{
			firstPokemonType += " / " + firstPokemon.getPokemonRace().getSecondType();
		}
		JLabel type1 = new JLabel(firstPokemon.getPokemonRace().getFirstType());
		type1.setFont(police);
		type1.setForeground(Color.WHITE);
		String secondPokemonType = secondPokemon.getPokemonRace().getFirstType();
		if (secondPokemonType != secondPokemon.getPokemonRace().getSecondType())
		{
			secondPokemonType += " / " + secondPokemon.getPokemonRace().getSecondType();
		}
		JLabel type2 = new JLabel(secondPokemonType);
		type2.setFont(police);
		type2.setForeground(Color.WHITE);
		JLabel Att1 = new JLabel("ATT : " + Integer.toString((firstPokemon.getCurrentStats().getAttack())));
		Att1.setFont(police);
		Att1.setForeground(Color.WHITE);
		JLabel Att2 = new JLabel("ATT : " + Integer.toString((secondPokemon.getCurrentStats().getAttack())));
		Att2.setFont(police);
		Att2.setForeground(Color.WHITE);
		JLabel Def1 = new JLabel("DEF : " + Integer.toString((firstPokemon.getCurrentStats().getDefense())));
		Def1.setFont(police);
		Def1.setForeground(Color.WHITE);
		JLabel Def2 = new JLabel("DEF : " + Integer.toString((secondPokemon.getCurrentStats().getDefense())));
		Def2.setFont(police);
		Def2.setForeground(Color.WHITE);
		JLabel AttS1 = new JLabel("ATT SPE : " + Integer.toString((firstPokemon.getCurrentStats().getSpecialAttack())));
		AttS1.setFont(police);
		AttS1.setForeground(Color.WHITE);
		JLabel AttS2 = new JLabel("ATT SPE : " + Integer.toString((secondPokemon.getCurrentStats().getSpecialAttack())));
		AttS2.setFont(police);
		AttS2.setForeground(Color.WHITE);
		JLabel DefS1 = new JLabel("DEF SPE : " + Integer.toString((firstPokemon.getCurrentStats().getSpecialDefense())));
		DefS1.setFont(police);
		DefS1.setForeground(Color.WHITE);
		JLabel DefS2 = new JLabel("DEF SPE : " + Integer.toString((secondPokemon.getCurrentStats().getSpecialDefense())));
		DefS2.setFont(police);
		DefS2.setForeground(Color.WHITE);
		JLabel VIT1 = new JLabel("SPD : " + Integer.toString((firstPokemon.getCurrentStats().getSpeed())));
		VIT1.setFont(police);
		VIT1.setForeground(Color.WHITE);
		JLabel VIT2 = new JLabel("SPD : " + Integer.toString((secondPokemon.getCurrentStats().getSpeed())));
		VIT2.setFont(police);
		VIT2.setForeground(Color.WHITE);
		JLabel ATT11 = new JLabel("Attack 1 : " + firstPokemon.getPokemonAttackByNumber(1));
		ATT11.setFont(police);
		ATT11.setForeground(Color.WHITE);
		JLabel ATT12 = new JLabel("Attack 2 : " + firstPokemon.getPokemonAttackByNumber(2));
		ATT12.setFont(police);
		ATT12.setForeground(Color.WHITE);
		JLabel ATT13 = new JLabel("Attack 3 : " + firstPokemon.getPokemonAttackByNumber(3));
		ATT13.setFont(police);
		ATT13.setForeground(Color.WHITE);
		JLabel ATT14 = new JLabel("Attack 4 : " + firstPokemon.getPokemonAttackByNumber(14));
		ATT14.setFont(police);
		ATT14.setForeground(Color.WHITE);
		JLabel ATT21 = new JLabel("Attack 1 : " + secondPokemon.getPokemonAttackByNumber(1));
		ATT21.setFont(police);
		ATT21.setForeground(Color.WHITE);
		JLabel ATT22 = new JLabel("Attack 2 : " + secondPokemon.getPokemonAttackByNumber(2));
		ATT22.setFont(police);
		ATT22.setForeground(Color.WHITE);
		JLabel ATT23 = new JLabel("Attack 3 : " + secondPokemon.getPokemonAttackByNumber(3));
		ATT23.setFont(police);
		ATT23.setForeground(Color.WHITE);
		JLabel ATT24 = new JLabel("Attack 4 : " + secondPokemon.getPokemonAttackByNumber(4));
		ATT24.setFont(police);
		ATT24.setForeground(Color.WHITE);
		//poke1
		this.add(nom1);this.add(nom2);
		this.add(vie1);this.add(vie2);
		this.add(imagepoke1);this.add(imagepoke2);
		this.add(type1);this.add(type2);
		this.add(Att1);this.add(Att2);
		this.add(Def1);this.add(Def2);
		this.add(AttS1);this.add(AttS2);
		this.add(DefS1);this.add(DefS2);
		this.add(VIT1);this.add(VIT2);
		this.add(ATT11);this.add(ATT21);
		this.add(ATT12);this.add(ATT22);
		this.add(ATT13);this.add(ATT23);
		this.add(ATT14);this.add(ATT24);
		this.getContentPane().add(Combat);this.getContentPane().add(Quitter);
		//poke2
		//Action Listener pour g�rer les actions sur les boutons
		Combat.addActionListener(this);
		Quitter.addActionListener(this);
		this.setVisible(true);
	}
	
	public void Combat(Fight fight)
	{
		BackgroundPanel fondJeu = new BackgroundPanel("battleBackground2.png");		
		//Param�tres de a fen�tre
				this.setTitle("POKEMILLION !");
				//Taille � modifier en fonction de l'image de fond !
				this.setSize(800,600);
				this.setResizable(false);
				this.setLocationRelativeTo(null);
				this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
				this.setContentPane(fondJeu);
				this.setLayout(new GridLayout(6,2,5,2));
				//
				Font police = new Font("Calibri",Font.BOLD, 20);
				Pokemon firstPokemon = fight.getFirstPokemon();
				Pokemon secondPokemon = fight.getSecondPokemon();
				JLabel vie1 = new JLabel(Integer.toString(firstPokemon.getCurrentHealth()) + " / " + Integer.toString(firstPokemon.getCurrentStats().getHealth()),SwingConstants.CENTER);
				vie1.setFont(police);
				JLabel vie2 = new JLabel(Integer.toString(secondPokemon.getCurrentHealth()) + " / " + Integer.toString(secondPokemon.getCurrentStats().getHealth()),SwingConstants.CENTER);
				vie2.setFont(police);
				JLabel nom1 = new JLabel(firstPokemon.getName(),SwingConstants.CENTER);
				nom1.setFont(police);
				JLabel nom2 = new JLabel(secondPokemon.getName(),SwingConstants.CENTER);
				nom2.setFont(police);
				JLabel imagepoke1 = new JLabel("",SwingConstants.CENTER);
				ImageIcon image1 = new ImageIcon("003.gif");
				imagepoke1.setIcon(image1);
				JLabel imagepoke2 = new JLabel("",SwingConstants.CENTER);
				ImageIcon image2 = new ImageIcon("003.gif");
				imagepoke2.setIcon(image2);
				/*JLabel DA1 = new JLabel("D�gats :",SwingConstants.CENTER);
				DA1.setFont(police);
				JLabel DA2 = new JLabel("D�gats :",SwingConstants.CENTER);
				DA2.setFont(police);
				JLabel AT1 = new JLabel("Attaque en cours :",SwingConstants.CENTER);
				AT1.setFont(police);
				JLabel AT2 = new JLabel("Attaque en cours :",SwingConstants.CENTER);
				AT2.setFont(police);*/
			
				//
				this.add(nom1);this.add(nom2);
				this.add(vie1);this.add(vie2);
				this.add(imagepoke1);this.add(imagepoke2);
				/*this.add(AT1);this.add(AT2);
				this.add(DA1);this.add(DA2);*/
				this.getContentPane().add(Menu);this.getContentPane().add(Quitter);
				
				//Action Listener pour g�rer les actions sur les boutons
				Combat.addActionListener(this);
				Quitter.addActionListener(this);
				Menu.addActionListener(this);
				this.setVisible(true);
	}
	
	 public void Aide() {
		  this.setTitle("Aide"); // on d�finit le titre
		  this.setSize(800,475); // on d�finit la taille
		  this.setLocationRelativeTo(null); // on centre la fenetre
		  this.setResizable(false);

		  this.setVisible(true);
		  JLabel regle = new JLabel();
		  JLabel regle2 = new JLabel();
		  JLabel regle3 = new JLabel();
		  JLabel regle4 = new JLabel();
		  JLabel regle5 = new JLabel();
		   
		  JLabel regle6 = new JLabel();
		  
		  JPanel panT = new BackgroundPanel("aide3.jpg"); //Image de Fond
		    panT.setBackground(Color.white);
		    panT.add(regle);
		    panT.add(regle2);
		    panT.add(regle3);
		    panT.add(regle4);
		    panT.add(regle5);
		    panT.add(regle6);
		    this.getContentPane().add(panT);
		    this.setVisible(true);
		  
		  
		  
	  }

	public void Credits() {
		  this.setTitle("Cr�dits"); // on d�finit le titre
		  this.setSize(800,475); // on d�finit la taille
		  this.setLocationRelativeTo(null); // on centre la fenetre
	      this.setResizable(false);
		  this.setVisible(true);
		  JLabel regle = new JLabel();
		  JLabel regle2 = new JLabel();
		  JLabel regle3 = new JLabel();
		  JLabel regle4 = new JLabel();
		  JLabel regle5 = new JLabel();
		  
		  JLabel regle6 = new JLabel();
		  
		  JPanel panT = new BackgroundPanel("credits.jpg");//Image de Fond
		    panT.setBackground(Color.white);
		    panT.add(regle);
		    panT.add(regle2);
		    panT.add(regle3);
		    panT.add(regle4);
		    panT.add(regle5);
		    panT.add(regle6);
		    this.getContentPane().add(panT);
		    this.setVisible(true);
		  
		  
		  
	  }
	
	
	public void actionPerformed (ActionEvent arg0)
	{
		if(arg0.getSource() ==  Jouer )
		{
			System.out.println("Action : Jouer");
			this.linkedGameModel.beginFights();
		}
		
		if(arg0.getSource() ==  Options )
		{
			fenetreMenu fen = new fenetreMenu(null);
			fen.Credits();
			System.out.println("Action : Options");
		}
		
		if(arg0.getSource() ==  Aide )
		{
			fenetreMenu fen1 = new fenetreMenu(null);
			fen1.Aide();
			System.out.println("Action : Aide");
		}
		
		if(arg0.getSource() ==  Menu )
		{
			System.out.println("Action : Menu");
			this.Menu();
		}
		if(arg0.getSource() ==  Combat )
		{
			System.out.println("Action : Combat");
			this.linkedGameModel.fightConduction(currentFight);
		}
		if(arg0.getSource() ==  Quitter )
		{
			System.out.println("Action : Quitter");
			System.exit(0);// A MODIFIE PAR LA FONCTION DE REMI POUR QUITTER LE JEU
		}
	}
	
	public void sendFightForFiche(Fight fight)
	{
		FichePoke(fight);
	}
}
