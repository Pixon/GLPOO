
public class Draw
{
	private int drawing[] = new int[7];
	
	/*****Constructor******/
	public Draw(int drawLine)
	{
		getDrawFromCSV(drawLine);
	}
	
	/*****Methods******/
	
	public void getDrawFromCSV(int drawLine)
	{
		//System.out.println(drawLine);
		try {
			Lottery lotteryDraw = new Lottery(drawLine, "src/LotteryCSV.csv");
			drawing = lotteryDraw.getDraw();
		}
		catch (Exception e) {}
		
		//Remplit le tableau avec la ligne de csv
		//fillDrawing();
	}
	public int getLevelNumber()
	{
		return this.drawing[0];
	}
	public int[] getAttackNumbers()
	{
		int[] attackNumbers = {this.drawing[1], this.drawing[2], this.drawing[3], this.drawing[4]};
		return attackNumbers;
	}
	public int getFirstStar()
	{
		//System.out.println(drawing[5]);
		return this.drawing[5];
	}
	public int getSecondStar()
	{
		return this.drawing[6];
	}
}
