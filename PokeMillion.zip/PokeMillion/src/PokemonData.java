import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;

import com.opencsv.CSVReader;

public class PokemonData {
	String[] row = null;

	private int id;
	private String name;
	private String type1;
	private String type2;
	private int pv;
	private int attack;
	private int defense;
	private int attSpec;
	private int defSpec;
	private int speed;
	private int nbAttack;
	private String list_attack;

	public PokemonData(int idPokemon, String list_pokemon, String list_attack) {
		this.list_attack = list_attack;

		try {
			CSVReader csvReader = new CSVReader(new FileReader(list_pokemon), ',');
			for (int i = 0; i < idPokemon+1 ; i++) {
				row = csvReader.readNext();

			}

			this.id = Integer.parseInt(row[0]);
			this.name = row[1];
			this.type1 = row[2];
			this.type2 = row[3];
			this.pv = Integer.parseInt(row[4]);
			this.attack = Integer.parseInt(row[5]);
			this.defense = Integer.parseInt(row[6]);
			this.attSpec = Integer.parseInt(row[7]);
			this.defSpec = Integer.parseInt(row[8]);
			this.speed = Integer.parseInt(row[9]);
			this.nbAttack = Integer.parseInt(row[10]);

			csvReader.close();
		} catch (Exception e) {
			System.err.println("Erreur pokemondata " + e.getMessage());

		}

	}

	public ArrayList<Integer> getallAttackid() {

		ArrayList<Integer> list_attack = new ArrayList<Integer>();
		int indice_debut_attack = 11;

		for (int i = 0; i < nbAttack; i++) {

			list_attack.add(Integer.parseInt(row[indice_debut_attack]));
			indice_debut_attack++;
		}
		return list_attack;
	}

	public String get_Attackname(int idAttack) {
		String name = null;
		String[] rowattack = null;
		try {
			CSVReader Reader = new CSVReader(new FileReader(list_attack), ',');

			for (int i = 0; i < idAttack + 1; i++) {

				rowattack = Reader.readNext();

			}
			
			Reader.close();
		} catch (IOException e) {
			System.out.println("Erreur get_Attackname");
		}
		name = rowattack[1];
		return name;
	}
	
	public String get_Attack_Type (int idAttack){
		String type = null;
		String[] rowattack = null;
		try {
			CSVReader Reader = new CSVReader(new FileReader(list_attack), ',');

			for (int i = 0; i < idAttack + 1; i++) {

				rowattack = Reader.readNext();

			}
			
			Reader.close();
		} catch (IOException e) {
			System.out.println("Erreur get_Attackname");
		}
		type = rowattack[2];
		return type;
	}

	public String get_Attack_Category (int idAttack){
		String category = null;
		String[] rowattack = null;
		try {
			CSVReader Reader = new CSVReader(new FileReader(list_attack), ',');

			for (int i = 0; i < idAttack + 1; i++) {

				rowattack = Reader.readNext();

			}
			
			Reader.close();
		} catch (IOException e) {
			System.out.println("Erreur get_Attackname");
		}
		category = rowattack[3];
		return category;
	}
	public int get_Attack_Power (int idAttack){
		int power;
		String[] rowattack = null;
		try {
			CSVReader Reader = new CSVReader(new FileReader(list_attack), ',');

			for (int i = 0; i < idAttack + 1; i++) {

				rowattack = Reader.readNext();

			}
			
			Reader.close();
		} catch (IOException e) {
			System.out.println("Erreur get_Attackname");
		}
		power = Integer.parseInt(rowattack[4]);
		return power;
	}
	public int getId() {
		return id;
	}

	public String getName() {
		return name;
	}

	public String getType1() {
		return type1;
	}

	public String getType2() {
		return type2;
	}

	public int getPv() {
		return pv;
	}

	public int getAttack() {
		return attack;
	}

	public int getDefense() {
		return defense;
	}

	public int getAttSpec() {
		return attSpec;
	}

	public int getDefSpec() {
		return defSpec;
	}

	public int getSpeed() {
		return speed;
	}

	public int getNbAttack() {
		
		return nbAttack;
	}

}
