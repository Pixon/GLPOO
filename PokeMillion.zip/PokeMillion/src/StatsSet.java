
public class StatsSet {
	private int health;
	private int attack;
	private int defense;
	private int specialAttack;
	private int specialDefense;
	private int speed;

	public StatsSet(int health, int attack, int defense, int specialAttack, int specialDefense, int speed){
		this.health=health;
		this.attack=attack;
		this.defense=defense;
		this.specialAttack=specialAttack;
		this.specialDefense=specialDefense;
		this.speed=speed;
	}

	public int getHealth(){
		return this.health;
	}
	public int getAttack(){
		return this.attack;
	}
	public int getDefense(){
		return this.defense;
	}
	public int getSpecialAttack(){
		return this.specialAttack;
	}
	public int getSpecialDefense(){
		return this.specialDefense;
	}
	public int getSpeed(){
		return this.speed;
	}
}
