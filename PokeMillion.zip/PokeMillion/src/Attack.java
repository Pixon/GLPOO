/*
import java.io.FileReader;

import com.opencsv.CSVReader;
*/
public class Attack
{
	private String name;
	private Type type;
	private Category category;
	private int power;
	private static Attack[] attacks = new Attack[92];
	/******Constructor*******/
	
	public Attack(String name, String type, String category, int power)
	{
		this.name = name;
		this.type = Type.valueOf(type);
		this.category = Category.valueOf(category);
		this.power = power;
	}
	
	/*******Methods*******/
	
	public static Attack getAttackFromGlobalIndex(int globalIndex)
	{
		return attacks[globalIndex];
	}
	
	public String getAttackName()
	{
		return this.name;
	}
	
	public Type getAttackType()
	{
		return this.type;
	}
	
	public Category getAttackCategory()
	{
		return this.category;
	}
	
	public int getAttackPower()
	{
		return this.power;
	}
}
