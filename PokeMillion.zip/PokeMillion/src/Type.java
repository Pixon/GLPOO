
public enum Type
{
	Normal("Normal"), Fighting("Fighting"), Fire("Fire"), Water("Water"), Flying("Flying"), Grass("Grass"), Poison("Poison"), Electric("Electric"), Ground("Ground"), Psychic("Psychic"), Rock("Rock"), Ice("Ice"), Bug("Bug"), Dragon("Dragon"), Ghost("Ghost"), Steel("Steel");
	String name;

	private Type(String nameStr)
	{
		this.name = nameStr;
	}

	public String getName()
	{
		return this.name;
	}
}
