import java.util.ArrayList;
import java.util.Locale.Category;
public class Race
{
	private int nbAttack;
	private int raceIndex;
	private String name;
	private ArrayList<Attack> possibleAttacks = new ArrayList<Attack>();
	private StatsSet baseStats;
	private Type[] type = new Type[2];
	private static Race[] races = new Race[111];
	
	private Race(int globalPokemonIndex)
	{
		addPokemonDataFromGlobalIndex(globalPokemonIndex);
	}
	
	public static Race getRace(int index)
	{
		if(isRaceAlreadyKnown(index) == false)
		{
			new Race(index);
			System.out.println("Pokemon ajoute au pokedex");
		}
		else
		{
			System.out.println("Deja connu");
		}
		return races[index];
	}
	
	private static boolean isRaceAlreadyKnown(int globalPokemonIndex)
	{
		if (races[globalPokemonIndex] != null)
			return true;
		else
			return false;
	}
	
	private void addPokemonDataFromGlobalIndex(int globalPokemonIndex)
	{
		PokemonData pokemonCSV = new PokemonData(globalPokemonIndex, "src/PokemonList.csv", "src/AttackListCSV.csv");
		
		addRaceToKnown(globalPokemonIndex, pokemonCSV);
		
		//System.out.println(races[globalPokemonIndex].getNbAttack());
	}
	
	
	private void addRaceToKnown(int globalPokemonIndex, PokemonData pokemonCSV)
	{
		races[globalPokemonIndex] = this;
		races[globalPokemonIndex].setName(pokemonCSV.getName());
		races[globalPokemonIndex].setPossibleAttacks(pokemonCSV);
		races[globalPokemonIndex].setType(pokemonCSV.getType1(), pokemonCSV.getType2());
		races[globalPokemonIndex].setBaseStats(pokemonCSV);
		races[globalPokemonIndex].setNbAttack();
	}
	
	private void setName(String name)
	{
		this.name = name;
	}
	
	private void setPossibleAttacks(PokemonData pokemonCSV)
	{
		for (int i=0; i< pokemonCSV.getNbAttack(); i++)
		{
			Attack attack = createAttackFromId(pokemonCSV, pokemonCSV.getallAttackid().get(i));
			this.possibleAttacks.add(attack);
		}
	}
	
	private Attack createAttackFromId(PokemonData pokemonCSV, int attackId)
	{
		String name = pokemonCSV.get_Attackname(attackId);
		String type = pokemonCSV.get_Attack_Type(attackId);
		String category = pokemonCSV.get_Attack_Category(attackId);
		int power = pokemonCSV.get_Attack_Power(attackId);
		
		Attack attackCreated = new Attack(name, type, category, power);
		return attackCreated;
	}
	
	private void setBaseStats(PokemonData pokemonCSV)
	{
		int health = pokemonCSV.getPv();
		int attack = pokemonCSV.getAttack();
		int defense = pokemonCSV.getDefense();
		int specialAttack = pokemonCSV.getAttSpec();
		int specialDefense = pokemonCSV.getDefSpec();
		int speed = pokemonCSV.getSpeed();
		this.baseStats = new StatsSet(health, attack, defense, specialAttack, specialDefense, speed);
	}
	private void setType(String firstType, String secondType)
	{
		this.type[0] = Type.valueOf(firstType);//new Type(firstType);
		this.type[1] = Type.valueOf(secondType);
	}
	public void setNbAttack()
	{
		this.nbAttack = this.possibleAttacks.size();
	}
	public Attack getPossibleAttackFromIndex(int index)
	{
		return possibleAttacks.get(index);
	}
	public int getNbAttack()
	{
		return nbAttack;
	}
	public int getRaceIndex()
	{
		return raceIndex;
	}
	public String getName()
	{
		return name;
	}
	public StatsSet getBaseStats()
	{
		return baseStats;
	}
	
	public String getFirstType()
	{
		return type[0].toString();
	}
	
	public String getSecondType()
	{
		return type[1].toString();
	}
	
	private void printPokemonInfos(PokemonData pokemonCSV)
	{
		System.out.println(pokemonCSV.getId() + " " + pokemonCSV.getName() + " " + pokemonCSV.getType1() + " "
				+ pokemonCSV.getType2() + " " + pokemonCSV.getPv() + " " + pokemonCSV.getAttack() + " "
				+ pokemonCSV.getDefense() + " " + pokemonCSV.getAttSpec() + " " + pokemonCSV.getDefSpec() + " "
				+ pokemonCSV.getSpeed() + " " + pokemonCSV.getNbAttack());
		
	}
}
