import java.util.ArrayList;
import java.util.Collections;
import java.util.Random;

public class Pokemon {
	private String name;
	private int currentHealth;
	private int level;
	private int iv;
	private Race pokemonRace;
	private StatsSet currentStats;
	private ArrayList<Attack> pokemonAttacks = new ArrayList<Attack>();

	public Pokemon(int level, int[] attackDraw, int pokemonIndex){
		pokemonRace = Race.getRace(pokemonIndex);
		this.level=level;
		setIv();
		this.name = pokemonRace.getName();
		currentStats = setCurrentStats();
		this.currentHealth = currentStats.getHealth();
		setPokemonAttacks(attackDraw);
		
	}
	private void setPokemonAttacks(int[] attackDraw){
		for(int i=0; i<4; i++)
		{
			int raceAttackIndex = attackDraw[i] % this.pokemonRace.getNbAttack();
			Attack attackToAdd = this.pokemonRace.getPossibleAttackFromIndex(raceAttackIndex);
			if(this.pokemonAttacks.contains(attackToAdd) == false)
			{
				this.pokemonAttacks.add(attackToAdd);
			}
		}
	}
	
	private int calcStats(int base){
		int result=(((base+this.iv)*2*this.level)/100)+5;
		return result;
	}
	private int calcHealth(int base){
		int result=(((base+this.iv)*2*this.level)/100)+this.level+10;
		return result;
	}
	private void setIv(){
		int min=1;
		int max=31;
		Random rand = new Random();
		this.iv=rand.nextInt(max - min + 1) + min;
	}
	private StatsSet setCurrentStats(){

		int health = calcHealth(pokemonRace.getBaseStats().getHealth());
		int attack = calcStats(pokemonRace.getBaseStats().getAttack());
		int defense = calcStats(pokemonRace.getBaseStats().getDefense());
		int specialAttack = calcStats(pokemonRace.getBaseStats().getSpecialAttack());
		int specialDefense = calcStats(pokemonRace.getBaseStats().getSpecialDefense());
		int speed = calcStats(pokemonRace.getBaseStats().getSpeed());
		StatsSet stats= new StatsSet(health, attack, defense, specialAttack, specialDefense, speed);
		return stats;
	}
	public void reduceHealth(int n){
		this.currentHealth -= n;
		if (currentHealth < 0)
			currentHealth = 0;
	}
	public String getName(){
		return this.name;
	}
	public int getCurrentHealth(){
		return this.currentHealth;
	}
	public int getLevel(){
		return this.level;
	}
	public int getIv(){
		return this.iv;
	}
	public StatsSet getCurrentStats(){
		return this.currentStats;
	}
	public Race getPokemonRace(){
		return this.pokemonRace;
	}
	
	public Attack getRandomAttack()
	{
		Collections.shuffle(pokemonAttacks);
		return this.pokemonAttacks.get(0);
	}
	
	public String getPokemonAttackByNumber(int n)
	{
		if (this.pokemonAttacks.size() >= n)
			return this.pokemonAttacks.get(n-1).getAttackName();
		return "";
	}
	
	public void hitByAttack(Attack attack, Pokemon attackingPokemon)
	{
		int attackPower = attack.getAttackPower();
		Category attackCategory = attack.getAttackCategory();
		int attackingPokemonLevel = attackingPokemon.getLevel();
		int pokemonAttackValue = attackingPokemon.getCurrentStats().getAttack();
		int hitPokemonDefense = this.getCurrentStats().getDefense();
		if (attackCategory == Category.Physical)
		{
			pokemonAttackValue = attackingPokemon.getCurrentStats().getAttack();
			hitPokemonDefense = this.getCurrentStats().getDefense();
			System.out.println(attackCategory + " " + attack.getAttackName());
		}
		else
		{
			pokemonAttackValue = attackingPokemon.getCurrentStats().getSpecialAttack();
			hitPokemonDefense = this.getCurrentStats().getSpecialDefense();
		}
		
		int damages = (int)((0.4 * attackingPokemonLevel + 2) * pokemonAttackValue * attackPower) / (hitPokemonDefense*50) + 2;
		//System.out.println(attackingPokemonLevel + " " + pokemonAttackValue + " " +pokemonAttackValue);
		
		this.reduceHealth(damages);
		
		System.out.println(this.getName() + " s'est pris " + damages + " d�gats");
		LogWriter log = new LogWriter();
		log.pokemonAttackWriter(attackingPokemon, this, attack, damages);
	}
	public ArrayList<Attack> getAttackArray() {
		return pokemonAttacks;
	}
}
