
import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

public class LotteryTest {

	private Lottery NumberLottery;
	private int[] ArrayLottery;

	@Before
	public void doBefore() {
		NumberLottery = new Lottery(3, "src/LotteryCSV.csv");
		ArrayLottery = NumberLottery.getDraw();
	}

	@Test
	public void test() {
		int[] testArray = { 7, 10, 5, 44, 34, 10, 2 };

		for (int i = 0; i < 7; i++) {

			assertEquals(testArray[i], ArrayLottery[i]);
		}
	}

}
