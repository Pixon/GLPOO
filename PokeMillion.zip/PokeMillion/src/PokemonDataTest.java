import static org.junit.Assert.*;

import java.util.ArrayList;

import org.junit.Before;
import org.junit.Test;

public class PokemonDataTest {

	private PokemonData pokemonTest;

	@Before
	public void doBefore() {
		pokemonTest = new PokemonData(4, "src/PokemonList.csv", "src/AttackListCSV.csv");
	}

	@Test
	public void idTest() {
		int id = 4;
		assertEquals(id, pokemonTest.getId());

	}

	@Test
	public void nameTest() {
		String name = "Salameche";
		assertEquals(name, pokemonTest.getName());

	}

	@Test
	public void type1Test() {
		String type1 = "Fire";
		assertEquals(type1, pokemonTest.getType1());

	}

	@Test
	public void type2Test() {
		String type2 = "Fire";
		assertEquals(type2, pokemonTest.getType2());

	}

	@Test
	public void pvTest() {
		int pv = 39;
		assertEquals(pv, pokemonTest.getPv());

	}

	@Test
	public void attackTest() {
		int attack = 52;
		assertEquals(attack, pokemonTest.getAttack());

	}

	@Test
	public void defenseTest() {
		int defense = 43;
		assertEquals(defense, pokemonTest.getDefense());

	}

	@Test
	public void attackSpecTest() {
		int attackSpec = 60;
		assertEquals(attackSpec, pokemonTest.getAttSpec());

	}

	@Test
	public void defenseSpecTest() {
		int defenseSpec = 50;
		assertEquals(defenseSpec, pokemonTest.getDefSpec());

	}

	@Test
	public void speedTest() {
		int speed = 65;
		assertEquals(speed, pokemonTest.getSpeed());

	}

	@Test
	public void NbAttackTest() {
		int NbAttack = 16;
		assertEquals(NbAttack, pokemonTest.getNbAttack());

	}

	@Test
	public void allAttackidTest() {
		ArrayList<Integer> allAttackid = new ArrayList<Integer>();
		allAttackid.add(8);
		allAttackid.add(12);
		allAttackid.add(26);
		allAttackid.add(29);
		allAttackid.add(34);
		allAttackid.add(44);
		allAttackid.add(57);
		allAttackid.add(62);
		allAttackid.add(66);
		allAttackid.add(70);
		allAttackid.add(72);
		allAttackid.add(76);
		allAttackid.add(81);
		allAttackid.add(83);
		allAttackid.add(85);
		allAttackid.add(90);
		assertEquals(allAttackid, pokemonTest.getallAttackid());

	}

	@Test
	public void AttacknameTest() {
		String Attackname = "danse flamme";
		assertEquals(Attackname, pokemonTest.get_Attackname(8));
	}

	@Test
	public void Attack_Type_Test() {
		String Attack_Type = "Fire";
		assertEquals(Attack_Type, pokemonTest.get_Attack_Type(8));
	}

	@Test
	public void Attack_Category_Test() {
		String Attack_Category = "Special";
		assertEquals(Attack_Category, pokemonTest.get_Attack_Category(8));
	}



}
