public enum Category
{
	Physical("Physical"), Special("Special");
	String name;

	private Category(String nameStr)
	{
		this.name = nameStr;
	}

	public String getName()
	{
		return this.name;
	}
}
