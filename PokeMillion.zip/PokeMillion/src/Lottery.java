import java.io.FileReader;

import com.opencsv.CSVReader;

public class Lottery {

	private int number[] = new int[7];
	String[] row = null;

	public Lottery(int numberOfRows,String csvFilename)
	{
		try{
			CSVReader csvReader = new CSVReader(new FileReader(csvFilename), ';');
			
			for (int i = 0; i < numberOfRows; i++)
			{
				row = csvReader.readNext();
			}
			csvReader.close();
		}
		catch(Exception e)
		{
			System.err.println("Erreur loterry " + e.getMessage());
		}
		this.number[0] = Integer.parseInt(row[4]);
		this.number[1] = Integer.parseInt(row[5]);
		this.number[2] = Integer.parseInt(row[6]);
		this.number[3] = Integer.parseInt(row[7]);
		this.number[4] = Integer.parseInt(row[8]);
		this.number[5] = Integer.parseInt(row[9]);
		this.number[6] = Integer.parseInt(row[10]);
	}
	
	public int[] getDraw ()
	{
		return number;
	}
	

}
