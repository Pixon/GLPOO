import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

public class LogWriter {
	private String logFileName = "log.txt";
	private File logFile;
	
	LogWriter(){
		this.logFile = new File(logFileName);
		
	}
	
	public void titleWriter(){
		try
		{
		    PrintWriter pw = new PrintWriter (new BufferedWriter (new FileWriter (logFile)));
		    pw.println ("Pokemillion");
		    pw.println ("Le g�n�rateur de combat pokemon");
		    
		    pw.close();
		}
		catch (IOException exception)
		{
		    System.out.println ("Erreur lors de la lecture : " + exception.getMessage());
		}
	}
	
	public void pokemonWriter(Pokemon pokemon){
		try
		{
		    PrintWriter pw = new PrintWriter (new BufferedWriter (new FileWriter (logFile)));
		    pw.println("*****");
		    pw.println(pokemon.getName());
		    pw.println();
		    pw.println("Statistiques du pokemon:");
		    StatsSet stats = pokemon.getCurrentStats();
		    pw.println("Sant�: " + stats.getHealth() + "\tVitesse: " + stats.getSpeed());
		    pw.println("Attaque: " + stats.getAttack() + "\tD�fense: " + stats.getDefense());
		    pw.println("Attaque sp�: " + stats.getSpecialAttack() + "\tD�fense sp�: " + stats.getSpecialDefense());
		    pw.println();
		    pw.println("Attaques:");
		    ArrayList<Attack> pokemonAttacks = pokemon.getAttackArray();
		    for(int i=0; i<pokemonAttacks.size(); i++){
		    	pw.println(pokemonAttacks.get(i).getAttackName() + "\tPuissance: " + pokemonAttacks.get(i).getAttackPower());
		    }
		    
		    pw.close();
		}
		catch (IOException exception)
		{
		    System.out.println ("Erreur lors de la lecture : " + exception.getMessage());
		}
	}
	
	public void pokemonAttackWriter(Pokemon attackingPokemon, Pokemon defendingPokemon, Attack attack, int damages){
		try
		{
		    
			PrintWriter pw = new PrintWriter (new BufferedWriter (new FileWriter (logFile)));
		    
			pw.println(attackingPokemon.getName() + " attaque " + attack.getAttackName());
		    pw.println(defendingPokemon.getName() + " a perdu " + damages);
		    pw.println(attackingPokemon.getName() + " " + attackingPokemon.getCurrentHealth() +" PV\t" + defendingPokemon.getName() + " " + defendingPokemon.getCurrentHealth() +" PV");
		    pw.close();
		}
		catch (IOException exception)
		{
		    System.out.println ("Erreur lors de la lecture : " + exception.getMessage());
		}
	}
	public void andFightWriter(Pokemon winer, Pokemon looser){
		try
		{
			PrintWriter pw = new PrintWriter (new BufferedWriter (new FileWriter (logFile)));
		    pw.println(looser.getName() + " est K.O.");
		    pw.println("Le gagnant est " + winer.getName());
			pw.close();
		}
		catch (IOException exception)
		{
		    System.out.println ("Erreur lors de la lecture : " + exception.getMessage());
		}
	}
}
