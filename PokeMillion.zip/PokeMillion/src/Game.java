import java.util.ArrayList;

public class Game
{
	
	private ArrayList<Attack> attackList = new ArrayList<Attack>();
	//On rempli la liste depuis le csv
	private int numberOfFights;
	private int drawingNumber;
	private Log gameLog;
	private fenetreMenu gameWindow;
	
	
	/******Constructor*******/
	
	public Game()
	{
		LogWriter log = new LogWriter();
		log.titleWriter();
		gameWindow = new fenetreMenu(this);
		gameWindow.Menu();
		setAttackList();
		numberOfFights = 0;
		drawingNumber = 1;
	}
	
	/*******Methods*******/
	
	private void setAttackList()
	{
		
	}
	public ArrayList<Attack> getAttackList()
	{
		return this.attackList;
	}
	
	public Attack getAttackFromListIndex(int attackIndex)
	{
		return this.attackList.get(attackIndex);
	}
	
	public void beginFights()
	{
		launchNewFight();
	}
	
	private void launchNewFight()
	{
		numberOfFights++;
		Draw firstDraw = getNewDraw();
		Draw secondDraw = getNewDraw();
		Fight fight = new Fight(firstDraw, secondDraw, gameLog);
		this.gameWindow.sendFightForFiche(fight);
	}
	
	public void fightConduction(Fight currentFight)
	{
		currentFight.beginFight();
		while (currentFight.isFightFinished() == false)
		{
			currentFight.goOn();
			this.gameWindow.Combat(currentFight);
		}
		endOfFight();
	}
	
	public int endOfFight()
	{
		System.out.println(numberOfFights);
		//launchNewFight();
		return -1;
		//Si l'utilisateur veut en lancer un autre
			//launchNewFight();
		//Sinon
			//quitGame();
	}
	
	private Draw getNewDraw()
	{
		drawingNumber++;
		Draw draw = new Draw(drawingNumber);
		return draw;
	}
	
	private int quitGame()
	{
		//(facultatif) Ouvrir le log
		return -1;
	}
}
