
public class Log
{
	
}
