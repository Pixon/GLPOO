import java.util.Random;
import java.io.*; 

public class Fight
{
	private int fightNumber;
	private Pokemon[] pokemonsInBattle = new Pokemon[2];
	private int attackingPokemonIndex;
	private LogWriter log = new LogWriter();
	
	/******Constructor*******/
	
	public Fight(Draw firstPokemonDraw, Draw secondPokemonDraw, Log currentLogfile)
	{
		createPokemonsFromDraws(firstPokemonDraw, secondPokemonDraw);
		//System.out.println(pokemonsInBattle[0].getCurrentStats().getHealth());
		attackingPokemonIndex = getFasterPokemonIndex();
	}
	
	/*******Methods*******/
	
	private void createPokemonsFromDraws(Draw firstPokemonDraw, Draw secondPokemonDraw)
	{
		pokemonsInBattle[0] = createPokemonFromDraw(firstPokemonDraw);
		System.out.println(pokemonsInBattle[0].getCurrentStats().getHealth() +" "+pokemonsInBattle[0].getCurrentStats().getAttack()+" "+pokemonsInBattle[0].getCurrentStats().getDefense()+" "+ pokemonsInBattle[0].getCurrentStats().getSpecialAttack()+" "+pokemonsInBattle[0].getCurrentStats().getSpecialDefense());
		pokemonsInBattle[1] = createPokemonFromDraw(secondPokemonDraw);
		System.out.println(pokemonsInBattle[1].getCurrentStats().getHealth() +" "+pokemonsInBattle[1].getCurrentStats().getAttack()+" "+pokemonsInBattle[1].getCurrentStats().getDefense()+" "+ pokemonsInBattle[1].getCurrentStats().getSpecialAttack()+" "+pokemonsInBattle[1].getCurrentStats().getSpecialDefense());
	}
	
	private Pokemon createPokemonFromDraw(Draw pokemonDraw)
	{
		int pokemonLevel = calculatePokemonLevel(pokemonDraw.getLevelNumber());
		int attacksNumbers[] = pokemonDraw.getAttackNumbers();
		int pokemonIndex = calculatePokemonIndex(pokemonDraw.getFirstStar(), pokemonDraw.getSecondStar());
		System.out.println("Pokemon of index number " + pokemonIndex);
		Pokemon pokemonCreated = new Pokemon(pokemonLevel, attacksNumbers, pokemonIndex);
		LogWriter log = new LogWriter();
		log.pokemonWriter(pokemonCreated);
		return pokemonCreated;
	}
	
	private int calculatePokemonLevel(int levelNumber)
	{
		int pokemonLevel = levelNumber * 2;
		Random rand = new Random();
		int compensation = rand.nextInt(2);		//Chiffre entier aléatoire entre 0 et 1
		pokemonLevel -= compensation;
		return pokemonLevel;			//Entre 1 et 100
	}
	
	private int calculatePokemonIndex(int firstStar, int secondStar)
	{
		firstStar--;
		//System.out.println(firstStar);
		secondStar--;
		int pokemonIndex = (firstStar) * 10;
		pokemonIndex += secondStar + 1;
		//System.out.println(pokemonIndex);
		return pokemonIndex;			//Entre 1 et 111
	}
	
	private int getFasterPokemonIndex()
	{
		int firstPokemonSpeed = pokemonsInBattle[0].getCurrentStats().getSpeed();
		int secondPokemonSpeed = pokemonsInBattle[1].getCurrentStats().getSpeed();
		if (firstPokemonSpeed >= secondPokemonSpeed)
			return 0;
		else
			return 1;
	}
	
	public void beginFight()
	{
		makePokemonAttack();
	}
	
	public void goOn()
	{
		try
		{
			Thread.sleep(500);
		} catch (InterruptedException e)
		{
			e.printStackTrace();
		}
		switchAttackingPokemon();
		makePokemonAttack();
	}
	
	private void switchAttackingPokemon()
	{
		this.attackingPokemonIndex++;
		this.attackingPokemonIndex %= 2;
	}
	
	private void makePokemonAttack()
	{
		System.out.println("Vie de " + pokemonsInBattle[0].getName() +  " = " + pokemonsInBattle[0].getCurrentHealth());
		System.out.println("Vie de " + pokemonsInBattle[1].getName() + " = " + pokemonsInBattle[1].getCurrentHealth());
		Attack attack = pokemonsInBattle[attackingPokemonIndex].getRandomAttack();
		pokemonsInBattle[(attackingPokemonIndex+1)%2].hitByAttack(attack, pokemonsInBattle[attackingPokemonIndex]);
		//On écrit les actions dans le log au fur et à mesure qu'on les effectue
	}
	
	public boolean isFightFinished()
	{
		for (Pokemon pokemon : pokemonsInBattle)
		{
			if(pokemon.getCurrentHealth() == 0)
			{
				System.out.println(pokemonsInBattle[(attackingPokemonIndex+1)%2].getName() + " est KO.");
				log.andFightWriter(pokemonsInBattle[attackingPokemonIndex], pokemonsInBattle[(attackingPokemonIndex+1)%2]);
				return true;
			}
		}
		return false;
	}
	
	public Pokemon getFirstPokemon()
	{
		return pokemonsInBattle[0];
	}
	public Pokemon getSecondPokemon()
	{
		return pokemonsInBattle[1];
	}
}
